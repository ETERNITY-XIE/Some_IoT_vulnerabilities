# Crash Evidence

This archive documents two independent `SIGSEGV` captures from the
`/login.cgi` NULL-password path in Belkin F9K1003 v1 firmware 1.00.42.

## Contents

```text
bin/httpd                         Original firmware HTTP server
bin/libc.so.0                     Original firmware uClibc
bin/lib_inject_o32.so             Comparison interposer used in the captured run
bin/httpd.sha256                  Hash of the analyzed HTTP server
core_17/core_httpd.684            Complete core dump, capture A
core_18/core_httpd.684            Complete core dump, capture B
core_17/crashes.yaml              Signal and PC summary, capture A
core_17/crash_registers.yaml      Full register frame, capture A
core_17/core_mappings.txt         Core file mapping notes
core_17/execution_metadata.txt    Process and binary metadata
core_17/gdb_session.log           GDB symbol, register, stack, and disassembly log
core_18/*                         Equivalent files for capture B
libc_strcmp_disassembly.txt       Original firmware uClibc strcmp disassembly
gdb_crash_summary.png             Rendered snapshot of key crash fields
SHA256SUMS.txt                    Integrity hashes
```

## Reproducing the GDB session

From the archive root:

```bash
gdb-multiarch bin/httpd core_17/core_httpd.684 -x gdb_commands.txt
```

The interposer changes the displayed fault PC but not the source-level
comparison semantics. The original `/lib/libc.so.0!strcmp` is also included in
`libc_strcmp_disassembly.txt`; it starts by loading through `a0` without a NULL
check.

## Key fault facts

```text
Process:              httpd
Signal:               SIGSEGV (11)
Password argument:    a0 = 0
Compared hash:        a1 = 0x00454040
Comparison wrapper RA 0x77fd8f08
user_login return:    0x0040666C
```

The address `0x0040666C` is found on the active stack and identifies the second
`strcmp()` call in `user_login()` as the caller.

## Integrity

Run:

```bash
sha256sum -c SHA256SUMS.txt
```
